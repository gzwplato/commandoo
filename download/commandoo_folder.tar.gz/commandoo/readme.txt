-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA1


Installing commandoo
- --------------------


Pleez read this whole file before running.


My gnuGPG key is 0x74E59DD3 2013-12-09
as JuliuS Inet (internet signing).


There are four versions available for Debian and debian derivatives:

64 bit QT
64 bit GTK
32 bit QT
32 bit GTK

available at:
  https://github.com/Juuliuus/commandoo/
alternative:
  https://www.timepirate.org/downloads.html

commandoo has been developed and tested in 64 bit Debian 8 (Jessie) 
and tested in 64 bit Kubuntu 14.04 KDE, as well as 32 bit Linux Mint 
(17.2 Rafaela). 

It's also been tested on Debian 9 (sid)  [I found button enabling/disabling 
is hard to see in 'sid', but this was also true of other programs, maybe it's 
just my system? Improvements will have to wait until I start developing in 
Debian 9 but commandoo is usable].

It should, therefore, work in all debian 8 & 9 linux derivatives.


commandoo is a self-sufficient (99.9%) file. Place the commandoo version you want
in this folder and run it (but read all of this file first pleez). 

You don't have to use this folder, you can place commandoo in any folder you 
like, but then you won't have the starter database, search examples, and cool
screenshots. 

On a first run there will be a series of messages regarding setup. 

See github link above for latest notes.


==============================

     IMPORTANT! ===> Information regarding QT versions. <== IMPORTANT!

You: "Aaaaagh! It doesn't run!!"
=========================
The 0.01% part:
The QT versions of commandoo use the QT widget set. If commandoo doesn't run 
don't get mad at me! It is simply a matter of needing to install a library called: 

libqt4pas5   

This library is found in standard linux repositories. Use your package manager or 
apt-get. It is a library that serves as the go-between for lazaraus pascal computer
language ('pas') and QT Libraries. 

And of course also make sure commandoo is marked as executable (it is shipped as 
executable so this shouldn't be necessary).

==============================


If you do choose to use this folder with db's and searches you get a 'starter' 
database (both a text based and a sql based; text base is default).

The starter database has more than 170 Linux commands and examples. You can add 
your own favorite commands and command lines at will! 
(Or even start new databases as you like)


If you want try the other executable (Qt if you used GTK, or GTK if you used qt, or, 
if in future, you download a commandoo update) all you need to do is replace the 
commandoo file ( !!AND install libqt4pas5 if you use the QT version!! ). 


If you use this folder, you also have a choice of 3 languages:

English
Pyrate
Wookie

Pyrate and Wookie were developed for testing language translation cod and I 
give them to you for fun. You won't like Wookie, probably, but if you are 
feeling brave...

Other translations are needed, if you feel up to it contact me through github. 

In future if any new translations become available they will be at the github site under
the 'languages' folder which is in the 'code' folder (the 'po_files' folder is a list of 
language files that are not yet translated). Translated language files will also be
at the TimePirate site.


commandoo was designed in QT widget set. So QT versions will be prettier than the GTK versions.

And I won't lie: There may be some irregularities and display issues in GTK versions but 
it does work and is usable. If the oddities are really bad try the other widget set (QT if 
you tried GTK, or GTK if you tried QT). Using the proper one makes a difference.


This program was built using free pascal and the Lazarus IDE. Thank you FPC and Lazarus.


Enjoy.

-----BEGIN PGP SIGNATURE-----
Version: GnuPG v1

iQIcBAEBAgAGBQJZhbrrAAoJEB21d6905Z3TC/UP+wdwyOhSt5Ew93g0C8oLYvT0
lhl7SkIVLjRDf26Jj7iD5kOXHyU1PEoJkYYZeJYAwWn3Sri/NqLD92RaRl5rtlyD
WPrC/pESKz+yK3Qumr62ulkVXrc5VL0Mpa1OqqTl7H36duwibtil7T68DAhTedmP
oab/C6qWo6NWCEFvrYTjEqU7Z7jMGQ+Nc9T3dlm3TEO2A0pZQDZfowdIJ9YLenl1
tsgz9fkplgQvqhXWKvmQ9/15xkqp1hMKQMazOHtLYLfIeeSE55fzZncgXHaF9EUA
pa3UIMo2F2O02VBLukTMpEE1JOQdzjsMuWWNHmBsM0XRAiufayinj0jT0LatktJ/
JxQYDj3MNfJUyg0uMFEOv3svPUf0JlKS67m3JFka9sgf/06MvSndoP1IrfSNrEHk
bh27a4OKdLBHXkjOee8thhFct6BZJjS+wxa4f2ijY+WFPieJi74cpwJLvijdMfzR
r83BlNAc8KGmWJxqoZdSm5kZq+4n5WiL86oipCWPHzdxVMS9ky7hJ8iCH7PrI50e
R7Hbjx1Y6OICODLp/cvCrorn0DgGyQJ40KaPokA51TYCpINlGG80+sn1M7zxVxm7
TSrE8pIwaWnxrdVYBHi8N1d8GYsCsNF3jhnB0EEsgLmdu3TrwAWZxTJjEf/Qp1dG
GWmzC54aqinr0VlhrZMJ
=pRSE
-----END PGP SIGNATURE-----
